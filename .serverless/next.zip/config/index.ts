export const locales = ['en', 'ar'];

export const baseURL = process.env.NEXT_PUBLIC_SITE_URL + "/api";