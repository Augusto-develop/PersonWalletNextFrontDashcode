import React from 'react'

const MenuIcon = () => {
    return (
        <div>MenuIcon</div>
    )
}

export default MenuIcon