
import React from 'react'
import SidebarContent from './sidebar-content'
import Logo from '@/components/logo'
import { Menu } from './menu'


const DashCodeSidebar = () => {
    return (
        <SidebarContent>



            <Menu />


        </SidebarContent>
    )
}

export default DashCodeSidebar