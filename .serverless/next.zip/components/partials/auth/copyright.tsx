

const Copyright = () => {
    const currentYear = new Date().getFullYear();
  return <>Copyright {currentYear}, Dashcode All Rights Reserved.</>;
};

export default Copyright;
