
export type Movement = {
  id: string;
  cartdebito: string;
  cartcredito: string;
  ocorrencia: string;
  valor: string;
  creditId: string;
  anofat: string;
  mesfat: string;
};