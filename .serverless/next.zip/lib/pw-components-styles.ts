export const pwButtonIconTable = "w-7 h-7 ring-offset-transparent border-default-200 dark:border-default-300 text-default-400 dark:color-icon-pw";
export const pwButtonTextTable = "w-auto h-7 ring-offset-transparent border-default-200 dark:border-default-300 text-default-400 dark:color-icon-pw";
