import React from 'react'

const Loading = () => {
    return (
        <div>loading..</div>
    )
}

export default Loading