
import { redirect } from '@/components/navigation'

const CreditsPage = () => {
  // redirect('/credits/creditcards')
  return (
    <h1 className=' text-2xl'> Welcome Credits </h1>
  )
}

export default CreditsPage