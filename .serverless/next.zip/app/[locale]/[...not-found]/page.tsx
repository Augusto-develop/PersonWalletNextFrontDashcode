import { notFound } from "next/navigation";

const page = () => {
    notFound();
};

export default page;
